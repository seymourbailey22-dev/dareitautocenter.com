# Dare-it Auto Center — appointment booking update

This static website sends appointment requests via FormSubmit (https://formsubmit.co) to Dareitautocenter@gmail.com. The business must open the first activation email from FormSubmit and approve the destination before relying on delivery. Test with a sample request and verify it arrives.

Customer information (name, phone, vehicle and repair notes) is sent to a third-party FormSubmit service. Review its terms/privacy policy before going live and add an appropriate privacy notice. No server-side appointment database is provided; appointments are not automatically confirmed.

To publish on Vercel Drop, upload the folder or the ZIP contents as a new production deployment to the existing project if supported; otherwise create a new project and reassign the domain only after confirming the replacement works.

Towing request and repair tracking/staff dashboard remain DEMO ONLY and are clearly labeled.
